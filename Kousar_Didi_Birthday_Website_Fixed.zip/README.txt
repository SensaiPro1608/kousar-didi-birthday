KOUSAR DIDI BIRTHDAY WEBSITE — FIXED INTERACTIVE VERSION 🐼💙

HOW TO USE
1. Extract this ZIP file.
2. Keep index.html, style.css, script.js and the assets folder together.
3. Double-click index.html to open it in Chrome or Edge.
4. Click the visible buttons: Roast Corner, Caring Corner, Cake Time, Surprise Gift, gallery tiles, and Music.

WHAT'S FIXED
- The controls are real visible buttons, not invisible hotspots placed over an image.
- The popups open and close, the cake button gives extra slices, and the gift button reveals a bonus wish.
- The music button plays a simple original chime made in the browser and can be paused.
- The generated artwork is included in assets/birthday-design.png.

CUSTOMIZE
Edit Hindi/Hinglish message text in script.js. Replace assets/birthday-design.png with your own picture if desired, keeping the same filename.
