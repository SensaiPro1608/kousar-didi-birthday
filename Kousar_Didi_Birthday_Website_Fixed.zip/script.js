(() => {
  "use strict";
  const modal = document.getElementById("modal");
  const modalTitle = document.getElementById("modal-title");
  const modalText = document.getElementById("modal-text");
  const modalEmoji = document.getElementById("modal-emoji");
  const modalAction = document.getElementById("modal-action");
  const toast = document.getElementById("toast");
  let toastTimer;
  let cakeSlices = 1;
  let audioContext = null;
  let musicOn = false;
  let musicTimer = null;
  let noteIndex = 0;

  const messages = {
    roast: {
      emoji: "🔥🐼", title: "Roast Corner 😂",
      text: "Didi, aap itni smart ho ki Google bhi aapse tips maange! 😭😂\n\nPar phone haath mein aate hi 2 ghante gayab—yeh kaunsa magic hai? 📱\n\nAur overthinking ki CEO toh aap hi ho! 👑",
      button: "Theek hai, ab pyaar bhi 💙"
    },
    caring: {
      emoji: "💙🫶", title: "Caring Corner",
      text: "Kousar Didi, sabka khayal rakhte-rakhte apna khayal rakhna mat bhoolna. 🫶\n\nAap strong ho, par aapko bhi rest, hasi aur support chahiye.\n\nHamesha khush raho, healthy raho—hum aapke saath hain. 💗",
      button: "Sending hugs 💙"
    },
    cake: {
      emoji: "🎂🐼", title: "Cake Time!",
      text: "Virtual cake ka sabse bada slice Kousar Didi ke liye! 🍰\n\nCandles blow karo, wish maango aur cake share karna mat bhoolna. ✨",
      button: "Get another slice 🍰"
    },
    gift: {
      emoji: "🎁💙", title: "Surprise Gift!",
      text: "Surpriseee, Kousar Didi! 🐼💙\n\nAapki life galaxies jitni beautiful, stars jitni bright aur cake jitni sweet ho.\n\nHappy Birthday! Aaj ka din sirf aapke naam. ✨",
      button: "Open another wish 💌"
    },
    final: {
      emoji: "🌌💙", title: "One Last Message",
      text: "Didi, aapki har achhi wish poori ho, life mein khushiyan aur success aaye, aur aap hamesha apni cute si smile ke saath shine karti raho.\n\nHappy Birthday, Kousar Didi! 🐼🎂💙",
      button: "Made with love 💙"
    }
  };

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
  }

  function openModal(key) {
    const item = messages[key];
    if (!item) return;
    modalEmoji.textContent = item.emoji;
    modalTitle.textContent = item.title;
    modalText.textContent = item.text;
    modalAction.textContent = item.button;
    modal.dataset.key = key;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    modalAction.focus();
  }
  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  }

  // Event delegation makes every visible surprise button work.
  document.addEventListener("click", event => {
    const opener = event.target.closest("[data-open]");
    if (opener) openModal(opener.dataset.open);
    const tile = event.target.closest("[data-gallery]");
    if (tile) {
      modalEmoji.textContent = tile.textContent.trim().split("\\n")[0];
      modalTitle.textContent = tile.dataset.gallery;
      modalText.textContent = "A cute little birthday memory for Kousar Didi! Add your own photos to personalize this section. 💙";
      modalAction.textContent = "So cute! 🐼";
      modal.dataset.key = "gallery";
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
    }
  });

  document.getElementById("closeModal").addEventListener("click", closeModal);
  modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });

  modalAction.addEventListener("click", () => {
    const key = modal.dataset.key;
    if (key === "cake") {
      cakeSlices += 1;
      modalEmoji.textContent = "🍰😋";
      modalTitle.textContent = `Cake slice #${cakeSlices}!`;
      modalText.textContent = "Birthday calories are on holiday today. Ek aur slice le lo, Didi! 😂💙";
      modalAction.textContent = "One more? 🍰";
    } else if (key === "gift") {
      modalEmoji.textContent = "💌✨";
      modalTitle.textContent = "Bonus Wish!";
      modalText.textContent = "Aap hamesha loved, valued aur happy feel karo. Keep shining, Kousar Didi! 💙🐼";
      modalAction.textContent = "Awww 💙";
      modal.dataset.key = "giftDone";
    } else {
      closeModal();
      showToast("Happy Birthday, Kousar Didi! 🐼🎂💙");
    }
  });

  // Small original chime loop via Web Audio; only starts after user clicks.
  const musicBtn = document.getElementById("musicBtn");
  function playNote(freq, duration = 0.22) {
    if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.07, audioContext.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + duration);
    osc.connect(gain); gain.connect(audioContext.destination);
    osc.start(); osc.stop(audioContext.currentTime + duration + 0.02);
  }
  const melody = [523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 783.99, 1046.5];
  musicBtn.addEventListener("click", async () => {
    if (musicOn) {
      musicOn = false;
      clearInterval(musicTimer);
      musicBtn.textContent = "♫ Music: Off";
      showToast("Birthday chime paused 🔇");
      return;
    }
    try {
      if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === "suspended") await audioContext.resume();
      musicOn = true;
      musicBtn.textContent = "♫ Music: On · Pause";
      playNote(melody[noteIndex++ % melody.length]);
      musicTimer = setInterval(() => {
        if (musicOn) playNote(melody[noteIndex++ % melody.length]);
      }, 330);
      showToast("Birthday chime playing 🎵");
    } catch (error) {
      showToast("Audio isn't supported in this browser.");
    }
  });
})();
